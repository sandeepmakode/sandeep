/**
 * Created by sandeep makode on 5/01/2017.
 */

var myApp= angular.module("myApp",[]);

myApp.controller("custController",['$scope','custService','$compile',function($scope,custService,$compile){

    function init(){
        custService.getInitData().then(function(data){
            $scope.customerData = data.data;
            localStorage.setItem('customerData',$scope.customerData);
        });
		
    }

    $scope.addCust = function() {
        var createNewCust = {
            "name" : $scope.newName,
            "location" : $scope.newLocation,
            "email" : $scope.newEmail
        };
		$scope.customerData.push(createNewCust);
        localStorage.setItem('customerData',$scope.customerData);
        $('#modalwindow').modal('hide');
    };

    $scope.showRightPanel = function(event) {
        var getID = event.currentTarget.id;
        $scope.selectedCust = {
            "name" : $("#"+getID).find('.custName').text(),
            "location" :  $("#"+getID).find('.custLocation').text(),
            "email" :  $("#"+getID).find('.custEmail').text()
        };

    };

    init()
}]);


myApp.service("custService",['$http','$q',function($http,$q){
    return {
        getInitData : function (){
            var deferred = $q.defer();
            return $http({
                url : "data/cust_data.json",
                method : "GET"
            }).success(function (data) {
                deferred.resolve(data);
            });
            return deferred.promise;
        }
    }
}]);

myApp.directive("addNew",[function(){
    return {
        restrict :"EA",
        templateUrl : 'partial/addCust.html',
        scope: {
            custData: '=custData'
        }
    }
}]);